// Input the arguments for the constructor
const data = [
  "Hello, Hardhat!", // The example Greeter.sol file needs a string
];
// Export the arguments to be picked up by the `hardhat.config.ts` deployment script
export { data };
