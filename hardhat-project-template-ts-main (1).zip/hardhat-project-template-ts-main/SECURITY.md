# 🛡️ Security Policy

## 📬 Reporting a Vulnerability

Please report any security issues you find to [email@address.com](mailto:email@address.com).
