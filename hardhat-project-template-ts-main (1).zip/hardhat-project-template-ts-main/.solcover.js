module.exports = {
  skipFiles: ["mocks/", "lib/", "test/", "Create2DeployerLocal.sol"],
};
