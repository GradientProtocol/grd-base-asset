// JavaScript module that exports the constructor as an argument list
// Required by the Hardhat plugin `hardhat-etherscan`
// See also here: https://hardhat.org/plugins/nomiclabs-hardhat-etherscan.html#complex-arguments

// eslint-disable-next-line no-undef
module.exports = [
  "Hello, Hardhat!", // The example Greeter.sol file needs a string
];
